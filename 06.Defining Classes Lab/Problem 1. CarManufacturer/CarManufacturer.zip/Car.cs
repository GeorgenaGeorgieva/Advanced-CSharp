﻿namespace Problem1.Car
{
    public class Car
    {
        public string Make { get; set; }
        
        public string Model { get; set; }

        public int Year { get; set; }
    }
}
